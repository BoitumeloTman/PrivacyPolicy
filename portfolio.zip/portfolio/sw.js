const CACHE_NAME = 'portfolio-v2';
const ASSETS = [
  '/',
  '/index.html',
  '/styles.css',
  '/script.js',
  '/Media.jpg',
  '/favicon.ico',
  '/favicon.svg',
  '/apple-touch-icon.png',
  '/splash-screen.png',
  '/Boitumelo_Tsholo_cv.docx',
  '/site.webmanifest'
];

// Install event - cache all static assets
self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => {
        console.log('Caching assets');
        return cache.addAll(ASSETS).catch(err => {
          console.error('Failed to cache some assets:', err);
        });
      })
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then(cacheNames => {
      return Promise.all(
        cacheNames.map(cache => {
          if (cache !== CACHE_NAME) {
            console.log('Deleting old cache:', cache);
            return caches.delete(cache);
          }
        })
      );
    })
  );
});

// Fetch event - network first with cache fallback
self.addEventListener('fetch', (e) => {
  // Skip non-GET requests and chrome-extension requests
  if (e.request.method !== 'GET' || e.request.url.startsWith('chrome-extension://')) {
    return;
  }

  e.respondWith(
    fetch(e.request)
      .then(networkResponse => {
        // If valid response, update cache
        if (networkResponse && networkResponse.status === 200) {
          const responseToCache = networkResponse.clone();
          caches.open(CACHE_NAME)
            .then(cache => cache.put(e.request, responseToCache));
        }
        return networkResponse;
      })
      .catch(() => {
        // Network failed, try cache
        return caches.match(e.request)
          .then(cachedResponse => cachedResponse || 
            new Response('Offline - content not available', {
              status: 503,
              statusText: 'Service Unavailable',
              headers: new Headers({'Content-Type': 'text/plain'})
            })
          );
      })
  );
});