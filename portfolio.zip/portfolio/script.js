// Enhanced fade-in on scroll with error handling and performance optimizations
document.addEventListener('DOMContentLoaded', function() {
  // Check if IntersectionObserver is supported
  if (!('IntersectionObserver' in window)) {
    // Fallback: show all elements immediately if Observer not supported
    document.querySelectorAll('.fade-in').forEach(el => {
      el.classList.add('show');
    });
    return;
  }

  const faders = document.querySelectorAll('.fade-in');
  
  // More sensitive options for mobile devices
  const appearOptions = {
    threshold: window.innerWidth < 768 ? 0.05 : 0.1,
    rootMargin: "0px 0px -100px 0px"
  };

  const appearOnScroll = new IntersectionObserver(function(entries, observer) {
    entries.forEach(entry => {
      // Skip if not intersecting
      if (!entry.isIntersecting) return;
      
      // Add show class with the appropriate delay
      const delayClass = Array.from(entry.target.classList)
        .find(cls => cls.startsWith('delay'));
      
      // Wait for the specified delay before showing
      setTimeout(() => {
        entry.target.classList.add("show");
      }, delayClass ? parseInt(delayClass.split('-')[1]) * 1000 : 0);
      
      // Stop observing after animation triggers
      observer.unobserve(entry.target);
    });
  }, appearOptions);

  // Observe each element with error handling
  faders.forEach(fader => {
    try {
      appearOnScroll.observe(fader);
    } catch (e) {
      console.error('Error observing element:', fader, e);
      fader.classList.add('show'); // Fallback
    }
  });

  // Trigger immediate check on load for elements already in view
  const checkVisibleImmediately = () => {
    faders.forEach(fader => {
      const rect = fader.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.9) {
        fader.classList.add('show');
        appearOnScroll.unobserve(fader);
      }
    });
  };
  
  // Run initial check and also after a slight delay
  checkVisibleImmediately();
  setTimeout(checkVisibleImmediately, 300);
});

// Optional: Add this to handle resize events and recheck visibility
let resizeTimer;
window.addEventListener('resize', function() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(function() {
    document.querySelectorAll('.fade-in:not(.show)').forEach(el => {
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.8) {
        el.classList.add('show');
      }
    });
  }, 200);
});